from clean_folder.clean import main

__ALL__ = ['main']