

def hello_world():
    print('Hello World!')


def func_some_code():
    print('This is func from some_code.py')