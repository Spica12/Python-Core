
def func_another_code():
    print('This is func from another_code.py')