from random_jokes import get_random_joke

__all__ = ['get_random_joke']