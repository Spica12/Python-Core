from setuptools import setup

setup(name='jokes',
      version='0.0.1',
      description='Very useless code',
      url='http://github.com/storborg/usefull',
      author='Flying Circus',
      author_email='flyingcircus@example.com',
      license='MIT',
      packages=['jokes'],
      install_requires=['markdown'],
      zip_safe=False)