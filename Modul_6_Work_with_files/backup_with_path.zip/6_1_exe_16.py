from PIL import Image

image = Image.open('Temp/example.png')

image.show()