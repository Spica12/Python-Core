my_tuple = (2, 5, 6, 7, 8, 9, 0, 20)

print(my_tuple[3])
print(my_tuple[2:6])

circle = {
    (0, 0): 'centre',
    (0, 1): '90',
    (1, 0): '0 or 360',
    (0, -1): '270',
    (-1, 0): '180'}

print(circle.get((0, 1)))

