map = {ord('з'): 'z', ord('ю'): 'uu'}
translated = 'зюзю'.translate(map)
print(translated)  # zu