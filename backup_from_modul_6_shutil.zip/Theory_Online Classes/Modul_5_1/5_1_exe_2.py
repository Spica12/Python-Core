# def find_states(key_word, letter_case=False):
#     actual_states = list()

#     if letter_case:
#         for i in range(len(articles_dict)):
#             if articles_dict[i]['playset'].find(key_word) != -1 or\
#             articles_dict[i]['command'].find(key_word) != -1:
#                 actual_states.append(articles_dict[i])
#     else:
#         for i in range(len(articles_dict)):
#             if articles_dict[i]['playset'].find(key_word) != -1 or\
#             articles_dict[i]['command'].lower()find(key_word) != -1:
#                 actual_states.append(articles_dict[i])


# articles_dict = [
#     {
#         "playset": "Semi final voleyball strike",
#         "command": "Super Star",
#         "year": 1989,
#     },
#     {
#         "playset": "Quater final Finansial competition",
#         "command": "Actual price",
#         "year": 2020,
#     },
#     {
#         "playset": "Glory speed test call centre of East Erope",
#         "command": "Modern Operators",
#         "year": 1921,
#     },
#     {
#         "playset": "Endless war From Age of Dragons",
#         "command": "Kings of Glory",
#         "year": 2012,
#     },
# ]