print('----------- Example 1 ----------')

x = 50

def func():

    x = 2
    print('Function: Local value x is', x)

func()
print('Global: x as bafore is', x)