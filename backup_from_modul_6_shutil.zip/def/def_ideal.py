
def add(a: int, b: int) -> int:
    """
    Function of adding two numbers

    Input:
    a = integer
    b = integer

    Output:
    :return - integer
    """

    a: int = 4
    b: int = 8

    return a + b

result: int = add()
print(result)