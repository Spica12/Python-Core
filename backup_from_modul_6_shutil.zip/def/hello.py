def say_hello(name):
    print(f'Hello {name}')