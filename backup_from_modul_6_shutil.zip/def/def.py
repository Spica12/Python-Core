def say_hello():
    print('Hello World!')

# Виклик функції
say_hello()

# Ще один виклик функції
say_hello()
