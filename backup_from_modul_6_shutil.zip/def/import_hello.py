from hello import say_hello



if __name__ == 'import_hello.py':
    print('You imported hello.py')
    say_hello('user')