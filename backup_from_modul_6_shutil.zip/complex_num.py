complex = 3.14 + 1j
print(complex) # (3.14 + 1j)

print(complex.real) # 3.14
print(complex.imag) # 1.0

# Якщо мінус першим, то в дужки не потрібно
complex = -2 + 3j
print(complex) # (-2 + 3j)

# Додавання двох комлпексних чисел
a = -2 + 3j
b = 3 + 4j
c = a + b
print(c)