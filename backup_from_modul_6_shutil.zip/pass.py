# pass - загглушкавикористовується якщо нам треба вкласти пустий код

if True:
    pass
print('Hello world!')
# Hello world!
