number = 10

result = (number % 2 == 0) and 'Even' or 'Odd'

print(result)