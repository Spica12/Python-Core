# list mut ord nu []
# tuple immut ord nu (,)
# set mut no un {}
# frozenset immut no un frozenset()
# dict mut no nu-un {'key': 'value'}
# string ord nu '' "" """""" ''''''

# 'I LoVE' + 'PYTHON'
