world_map = [[' ', ' ', ' '],
             [' ', ' ', ' '],
             [' ', ' ', ' ']]

world_map[0][0] = 'X'

for row in world_map:
    print(row)