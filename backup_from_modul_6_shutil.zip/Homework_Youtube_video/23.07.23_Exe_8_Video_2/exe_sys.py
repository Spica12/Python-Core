import sys

def func(my_list):
    print(my_list)

    return my_list

a = [1, 2, 3, 4]
func(a)

print(sys.argv)