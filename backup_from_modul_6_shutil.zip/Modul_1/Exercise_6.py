first_name = 'Vitalii'
last_name = 'Savenko'
full_name = first_name + ' ' + last_name