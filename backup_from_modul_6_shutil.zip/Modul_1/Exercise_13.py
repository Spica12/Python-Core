length = "2.75"
width = "1.75"
area = float(float(length) * float(width))
show = f"With width {width} and length {length} of the room, its area is equal to {area}"

print(show)