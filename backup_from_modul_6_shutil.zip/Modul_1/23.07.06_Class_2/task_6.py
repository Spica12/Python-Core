# Дано дійсне число х. Скласти програму знаходження значення 
# виразу 2x4-3x3+4х2-5х + 6.

num_x = float(input('Enter number X:'))

result = 2 * num_x * 4 - 3 * num_x * 3 + 4 * num_x * 2 - 5 * num_x + 6

print(f'Result= {result}')