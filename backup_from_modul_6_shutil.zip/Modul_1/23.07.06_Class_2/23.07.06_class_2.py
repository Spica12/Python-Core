print(1/1)

none = 2
print(none)

print(3 +4 >= 3 == True)

#print(0/0)

print(35/4) #8.75
print(35//4) #8

print(4 ** 0.5)

print(2 + 2 * 2 + 2)

b = 5
# b = b + 3
b = b - 2
print(b)

s1 = 'some' + "string"
print(s1)

# None = 3
# None2 = 2 
# AllNone = None + None2

a = 3
b = 4
print(f'{a} + {b} = {a + b}')

