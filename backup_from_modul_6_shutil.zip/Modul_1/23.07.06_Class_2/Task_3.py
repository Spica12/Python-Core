# Дано сторону квадрата a (вводиться користувачем). Скласти програму 
# знаходження його периметра.

side = float(input('Enter length side: '))

perimetr = side * 4

print(f'Perimetr equal = {perimetr} if side = {side}')