rate = 1.68
value_day = 358
value_night = 103
#Payment for electricity for the current month
payment = rate * value_day + rate / 2 * value_night
print(payment)