length = 0.1
width = 0.2
area = length * width
show = f"With width {width} and length {length} of the room, its area is equal to {area}"

print(show) #0.020000000000000004