rate = 1.68
value_day = 70
value_night = 60
payment = rate * value_day + value_night * (rate / 2)
print(payment)