name = 'Vitalii'
age = 33
is_active = True
subscription = None