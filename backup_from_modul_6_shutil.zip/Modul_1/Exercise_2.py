rate = 1.68
value = 134
payment = rate * value