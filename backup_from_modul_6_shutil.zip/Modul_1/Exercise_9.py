a = -2 + 3j
b = 4 + 2j
result = a + b

print(result)