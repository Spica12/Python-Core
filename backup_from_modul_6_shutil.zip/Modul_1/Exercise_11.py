is_active = True
is_delete = False