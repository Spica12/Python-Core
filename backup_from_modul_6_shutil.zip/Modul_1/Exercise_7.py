first_name = "John"
last_name = "Smith"
full_name = first_name + " " + last_name

message = f"""Dear {first_name}, we inform you that you have purchased a ticket to travel 
to the island of Mauritius. Departure June 31 of this year. Have a passport 
at {full_name}. We are looking forward to seeing you!"""

print(message)