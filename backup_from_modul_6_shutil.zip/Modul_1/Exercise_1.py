name = 'Vitalii'
age = 33