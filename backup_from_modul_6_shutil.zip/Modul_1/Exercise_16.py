length = float(input('Length: '))
width = float(input('Width: '))
area = length * width

print(area)
x = input()
