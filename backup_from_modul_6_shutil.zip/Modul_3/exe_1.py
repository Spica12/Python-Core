# Створіть функцію greeting, яка всередині виводить вітальне 
# повідомлення print('Hello world!'). І викличте її.

def greeting():
    print('Hello world!')


greeting()