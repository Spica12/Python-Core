from random import randrange

list = ['one', 'two', 'three', 'four']



print(randrange(len(list)))
