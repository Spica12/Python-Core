num_1 = 6
num_2 = 7

# Перевірка місця збереження у пам'яті
print('Path of sentence in memory', id(num_1))
print('Path of sentence in memory', id(num_2))