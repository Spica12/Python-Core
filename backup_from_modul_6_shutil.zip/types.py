# int()
# float()
# str()
# bool()

num = round(7 / 3, 3)
print(num)