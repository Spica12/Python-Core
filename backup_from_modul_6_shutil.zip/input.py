name = input('Як тебе зовуть? ')

# Функція Input повертає str - рядок
print(f'Привіт, {name}')

age = input('Скільки тобі років? ')
age = int(age)

print(f'Тобі {age} років')


