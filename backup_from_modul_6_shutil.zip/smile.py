print('\N{slightly smiling face}') # Використання escape sequence \N{}
#                                       з назвою символу   

print('\u263A') # Смайлик у шістнадцятковому форматі

print('\U0001F600') # Смайлик у 16-ому форматі з великою букви U