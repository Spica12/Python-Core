print('---------- Приклад 1 ----------')
for variable in range(10):
    print(variable)

print('---------- Приклад 2 ----------')
for variable in range(5, 10):
    print(variable)

print('---------- Приклад 3 ----------')
for variable in range(5, 10, 2):
    print(variable)

print('---------- Приклад 4 ----------')
a = range(0, 10)
print(a)
# range(0, 10)

a = list(range(0, 10))
print(a)
# [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

a = list(range(6, 10))
print(a)
# [6, 7, 8, 9]