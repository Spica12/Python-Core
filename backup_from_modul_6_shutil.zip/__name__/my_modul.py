def func():
    print(__name__)


message = 'My message'

if __name__ == '__main__':
    print('asd')
    func()
    print()

