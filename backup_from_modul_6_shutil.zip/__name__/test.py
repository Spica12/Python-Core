import my_modul

my_modul.func()

print(my_modul.message)