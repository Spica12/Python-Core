import my_modul

my_modul.func()