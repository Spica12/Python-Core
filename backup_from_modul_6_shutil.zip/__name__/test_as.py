from my_modul import func as my_func

my_func()