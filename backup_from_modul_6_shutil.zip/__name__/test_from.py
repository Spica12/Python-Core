from my_modul import func, message

func()
print(message)
