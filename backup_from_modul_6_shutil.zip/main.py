print('Hello world!!!')
print('Hello world from Notebook')